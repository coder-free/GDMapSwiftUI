//
//  MATopographyOverlayRenderer.h
//  MAMapKit
//
//  Created by JZ on 2021/3/17.
//  Copyright © 2021 Amap. All rights reserved.
//

#import "MAMapKit.h"
#import "MATileOverlayRenderer.h"

NS_ASSUME_NONNULL_BEGIN

@interface MATerrainOverlayRenderer : MATileOverlayRenderer

@end

NS_ASSUME_NONNULL_END
